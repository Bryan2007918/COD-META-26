# Meta 26 — Rumbo al Mundial Codigo 26

> Plataforma digital de experiencia post-carrera para corredores.

![Meta 26](https://img.shields.io/badge/Meta_26-Codigo_26-FF4D6A?style=for-the-badge)
![React](https://img.shields.io/badge/React-18-00D4FF?style=for-the-badge&logo=react)
![Status](https://img.shields.io/badge/Status-MVP-10B981?style=for-the-badge)

## ¿Que es Meta 26?

Meta 26 es una aplicacion web que transforma la experiencia de los corredores despues de cruzar la meta. No es solo una tabla de resultados — es una experiencia digital completa con medallas, certificados, rankings y recompensas.

## Evento Actual

**Rumbo al Mundial Codigo 26**
- 📏 Carrera de 5K
- 📅 3 de mayo de 2026
- 📍 Ciclopista Rio Mayo, Cuernavaca, Morelos
- 🏃 150 — 200 corredores aprox.
- 🏅 Categorias: Varonil y Femenil

## Funciones

- ✅ Registro de usuario con asignacion automatica de dorsal
- ✅ Inicio de sesion
- ✅ Busqueda de corredor por nombre o dorsal
- ✅ Resultado detallado con estadisticas (tiempo, posicion, ritmo, calorias)
- ✅ Rankings por rama (Varonil / Femenil / General)
- ✅ Medalla digital con diseño visual
- ✅ Certificado oficial con nombre y numero de corredor
- ✅ Zona de recompensas y cupones para Top 10
- ✅ Mapa de la ruta del evento
- ✅ Seccion "Mis carreras" (preparada para multiples eventos)
- ✅ Cuenta regresiva al evento
- ✅ Perfil del corredor con dorsal asignado

## Tecnologias

- React 18
- JavaScript (sin TypeScript)
- CSS-in-JS (estilos inline)
- Google Fonts (Outfit + JetBrains Mono)
- Sin backend (datos locales para MVP)

## Como ejecutar localmente

### Opcion 1: Con Vite (recomendado)

```bash
# Clonar el repositorio
git clone https://github.com/TU_USUARIO/meta26.git
cd meta26

# Instalar dependencias
npm install

# Iniciar servidor de desarrollo
npm run dev
```

### Opcion 2: Abrir el archivo HTML directamente

El archivo `index.html` se puede abrir directamente en el navegador para una vista rapida.

## Estructura del proyecto

```
meta26/
├── index.html          ← Pagina principal (se puede abrir directo)
├── src/
│   └── App.jsx         ← Componente principal de React (toda la app)
├── package.json        ← Dependencias del proyecto
├── vite.config.js      ← Configuracion de Vite
└── README.md           ← Este archivo
```

## Como subir a GitHub

```bash
# 1. Crear repositorio en github.com (boton "New repository")
# 2. En tu terminal:

git init
git add .
git commit -m "Meta 26 - Rumbo al Mundial Codigo 26 - MVP"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/meta26.git
git push -u origin main
```

## Desplegar en Vercel (gratis)

1. Sube el proyecto a GitHub
2. Ve a [vercel.com](https://vercel.com)
3. Conecta tu cuenta de GitHub
4. Selecciona el repositorio `meta26`
5. Vercel detecta automaticamente que es un proyecto Vite
6. Click en "Deploy"
7. Tu app estara en vivo en `https://meta26.vercel.app`

## Proximas funciones (Roadmap)

- [ ] Backend con Supabase (base de datos real)
- [ ] Galeria de fotos del evento
- [ ] Sistema de insignias/logros
- [ ] Panel de administracion para organizadores
- [ ] Mas eventos y carreras
- [ ] Cupones de patrocinadores reales

## Autor

Desarrollado como proyecto MVP para la carrera Rumbo al Mundial Codigo 26.

---

**Meta 26** — Tu carrera no termina en la meta. Ahi comienza la experiencia.
