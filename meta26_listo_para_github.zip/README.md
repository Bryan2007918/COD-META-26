# Meta 26 - Rumbo al Mundial Codigo 26

Plataforma digital de experiencia post-carrera para corredores.

## Evento

**Rumbo al Mundial Codigo 26**
- Carrera de 5K
- 3 de mayo de 2026
- Ciclopista Rio Mayo, Cuernavaca, Morelos
- 150 - 200 corredores aprox.
- Categorias: Varonil y Femenil

## Como ejecutar

```bash
npm install
npm run dev
```

## Desplegar en Vercel

1. Sube a GitHub
2. Conecta en vercel.com
3. Deploy automatico

## Tecnologias

- React 18
- Vite
- JavaScript
